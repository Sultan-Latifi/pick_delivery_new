sap.ui.define([
	"com/mindsquare/mde_remove_delivery/mind2_mde_2_remove_delivery/test/unit/controller/Lieferungauswahl.controller"
], function () {
	"use strict";
});